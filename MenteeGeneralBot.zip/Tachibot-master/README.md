# Tachibot
A basic Manga bot for the Tachiyomi Discord server.

>Note: As we have reached the current server cap for unverified bots, you cannot add the bot to your server. An alternative is setting it up yourself.
See [this](https://github.com/SynderBlack/Tachibot/issues/6#issuecomment-788161929) issue for more information.

Invite Tachibot to your server by clicking [here](https://discordapp.com/oauth2/authorize?client_id=547050799164030976&scope=bot&permissions=24576)
